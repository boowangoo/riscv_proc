#ifndef _PASS_FAIL_H_

int pass();
int fail();
#endif 
